
function addTask() {
  const input = document.getElementById('taskInput');
  const taskText = input.value.trim();
  if (!taskText) return;
  const task = document.createElement('li');
  task.textContent = taskText;
  task.onclick = () => {
    task.remove();
    saveTasks();
  };
  document.getElementById('taskList').appendChild(task);
  input.value = '';
  saveTasks();
}
function saveTasks() {
  const tasks = [];
  document.querySelectorAll('#taskList li').forEach(li => tasks.push(li.textContent));
  localStorage.setItem('tasks', JSON.stringify(tasks));
}
function loadTasks() {
  const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks.forEach(t => {
    const li = document.createElement('li');
    li.textContent = t;
    li.onclick = () => {
      li.remove();
      saveTasks();
    };
    document.getElementById('taskList').appendChild(li);
  });
}
window.onload = loadTasks;
