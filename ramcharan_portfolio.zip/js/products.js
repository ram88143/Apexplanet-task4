
const products = [
  { name: "Smartphone", category: "electronics", price: 20000 },
  { name: "T-Shirt", category: "clothing", price: 500 },
  { name: "Laptop", category: "electronics", price: 50000 },
  { name: "Jeans", category: "clothing", price: 1200 },
];
function renderProducts() {
  const filter = document.getElementById('filter').value;
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';
  const filtered = filter === 'all' ? products : products.filter(p => p.category === filter);
  filtered.forEach(product => {
    const div = document.createElement('div');
    div.className = 'product-card';
    div.innerHTML = `<h3>${product.name}</h3><p>₹${product.price}</p>`;
    grid.appendChild(div);
  });
}
window.onload = renderProducts;
